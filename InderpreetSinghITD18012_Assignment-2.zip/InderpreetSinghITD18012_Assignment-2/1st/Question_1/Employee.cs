﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Question_1
{
    class Employee
    {
        string name;
        int hours_worked;
        double salaryperhour;
        bool namevalidate;
        bool hoursvalidate;
        public Employee()
        {
            name = "";
            hours_worked = 0;
            salaryperhour = 0;
        }

        public Employee(string a, int b, double c)
        {
            name = a;
            hours_worked = b;
            salaryperhour = c;
        }

        public void validator()
        {

            for (int i = 0; i < name.Length; i++)
            {
                if(!char.IsLetter(name, i))
                {
                    namevalidate = false;
                    break;
                }
                else
                {
                    namevalidate = true;
                }
            }

            for (int i = 0; i < hours_worked.ToString().Length; i++)
            {
                if(!char.IsDigit(hours_worked.ToString(), i))
                {
                    hoursvalidate = false;
                    break;
                }
                else
                {
                    hoursvalidate = true;
                }
            }

            if(!namevalidate)
            {
                System.Windows.Forms.MessageBox.Show("Invalid name");
            }

            else if(!hoursvalidate)
            {
                System.Windows.Forms.MessageBox.Show("Invalid hours worked");
            }

            else if(name == "")
            {
                System.Windows.Forms.MessageBox.Show("Please enter a name");
            }

            else if(hours_worked <= 0)
            {
                System.Windows.Forms.MessageBox.Show("Hours worked can not be equal to or less than zero");
            }

            else
            {
                double salary = calculateSalary();
                System.Windows.Forms.MessageBox.Show("The salary of " + name + "is " + salary.ToString() + @"$");
            }
        }

        public double calculateSalary()
        {
            double salary;
            salary = salaryperhour * hours_worked;
            return salary;
        }
    }
}
